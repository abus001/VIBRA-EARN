# Production backend and safety checklist

## Core services
- Firebase Authentication: email/phone verification, secure password reset.
- Firestore: users, videos, view events, creator ledger, withdrawal requests, moderation reports.
- Firebase Storage: upload limits, MIME/type validation, malware scanning pipeline where available.
- Cloud Functions: server-authoritative view validation, reward ledger writes, threshold notification, withdrawal workflow.
- Admin web dashboard: role-based access control, audit logs, moderation queue, payout approvals.

## Suggested data model
- `users/{uid}`: displayName, language, ageVerified, status, createdAt, role.
- `videos/{videoId}`: ownerUid, storagePath, caption, visibility, moderationStatus, createdAt, validViewCount.
- `viewEvents/{eventId}`: viewerUid, videoId, serverTimestamp, validationStatus, fraudSignals.
- `wallets/{uid}`: availableBalanceKobo, lifetimeEarnedKobo, updatedAt.
- `walletLedger/{entryId}`: uid, videoId, amountKobo, type, status, createdAt.
- `withdrawals/{requestId}`: uid, amountKobo, payoutMethod, encryptedOrTokenizedDestination, status, reviewedBy, createdAt.

Store money as integer kobo (₦50 = 5000 kobo) to avoid floating-point errors. Keep all wallet writes server-side.

## Reward logic
- Product rule: ₦50 per *validated* view, not every raw playback.
- Minimum withdrawal: ₦25,000.
- Server must enforce one eligible reward per unique viewer/video under a defined policy, minimum watch duration, rate limits, device/account abuse checks, and suspicious-traffic review.
- Never let the client app increment balances or submit its own trusted view count.
- Add a configurable budget cap and pause switch. Validate revenue and payout reserves before enabling this reward rate.

## Notifications
- When available balance first crosses ₦25,000, create an in-app notification in the user's selected language.
- Send push notification via Firebase Cloud Messaging only after user consent and valid device token.
- Do not repeatedly send the threshold notification.

## Payouts
- Bank transfer, OPay and PalmPay need a legitimate payout provider/partner and business onboarding.
- Keep provider secret keys in Cloud Functions/server secret manager, never in the Android app.
- Verify account name and payout status with provider APIs; use idempotency keys and reconciliation.
- Admin approval, audit trail, KYC/AML and applicable Nigerian legal/regulatory requirements must be reviewed with qualified professionals.
- Never mark a withdrawal as paid until provider confirms success.

## Trust, safety and compliance
- Age gate and age assurance appropriate to the content; restrict adult content to adults and comply with app-store rules.
- Obtain explicit consent from every person depicted; prohibit non-consensual intimate imagery, minors, coercion, and illegal content.
- Report, block, takedown, appeal and moderation tools.
- Terms, privacy policy, retention/deletion process and data security review.
- Review Google Play user-generated-content and payments policies before publishing.
