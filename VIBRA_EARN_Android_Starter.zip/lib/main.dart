import 'package:flutter/material.dart';

void main() => runApp(const VibraEarnApp());

const rewardPerValidView = 50; // NGN
const minimumWithdrawal = 25000;

class VibraEarnApp extends StatefulWidget {
  const VibraEarnApp({super.key});
  @override
  State<VibraEarnApp> createState() => _VibraEarnAppState();
}

class _VibraEarnAppState extends State<VibraEarnApp> {
  String language = 'Hausa';
  int selectedTab = 0;
  int validViews = 120;
  bool notificationShown = false;

  int get balance => validViews * rewardPerValidView;

  String tr(String ha, String en) => language == 'English' ? en : ha;

  @override
  Widget build(BuildContext context) {
    final pages = [
      FeedPage(tr: tr),
      UploadPage(tr: tr),
      WalletPage(
        tr: tr,
        balance: balance,
        validViews: validViews,
        onWithdraw: () => _withdraw(context),
      ),
      SettingsPage(
        language: language,
        onLanguageChanged: (v) => setState(() => language = v),
        tr: tr,
      ),
    ];
    if (balance >= minimumWithdrawal && !notificationShown) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && !notificationShown) {
          setState(() => notificationShown = true);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(tr(
              'Taya murna! Ka kai ₦25,000. Za ka iya neman cire kuɗinka.',
              'Congratulations! You reached ₦25,000. You can request a withdrawal.',
            ))),
          );
        }
      });
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VIBRA EARN',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7655E8)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF101018),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF101018), foregroundColor: Colors.white,
        ),
        textTheme: ThemeData.dark().textTheme,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('VIBRA EARN', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
              tooltip: tr('Sanarwa', 'Notifications'),
              onPressed: () => showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text(tr('Sanarwa', 'Notifications')),
                  content: Text(tr(
                    'Za a sanar da kai idan ka kai ₦25,000.',
                    'You will be notified when your balance reaches ₦25,000.',
                  )),
                ),
              ),
              icon: const Icon(Icons.notifications_none),
            )
          ],
        ),
        body: pages[selectedTab],
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedTab,
          onDestinationSelected: (i) => setState(() => selectedTab = i),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.play_circle_outline), label: tr('Kallo', 'Watch')),
            NavigationDestination(icon: const Icon(Icons.add_box_outlined), label: tr('Upload', 'Upload')),
            NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), label: tr('Wallet', 'Wallet')),
            NavigationDestination(icon: const Icon(Icons.settings_outlined), label: tr('Saiti', 'Settings')),
          ],
        ),
      ),
    );
  }

  void _withdraw(BuildContext context) {
    if (balance < minimumWithdrawal) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Sai ka kai ₦25,000 kafin withdrawal.', 'Reach ₦25,000 before requesting a withdrawal.'))),
      );
      return;
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => WithdrawalSheet(tr: tr),
    );
  }
}

class FeedPage extends StatelessWidget {
  final String Function(String, String) tr;
  const FeedPage({super.key, required this.tr});

  @override
  Widget build(BuildContext context) => PageView(
    scrollDirection: Axis.vertical,
    children: [
      _videoCard(context, 'VIBRA EARN', tr('Bidiyon gwaji — swipe sama don kallon na gaba', 'Sample video — swipe up for the next one'), Icons.movie_outlined),
      _videoCard(context, 'Creator demo', tr('Za a nuna bidiyoyin users daga server a nan.', 'User videos from the server will appear here.'), Icons.video_library_outlined),
    ],
  );

  Widget _videoCard(BuildContext context, String creator, String caption, IconData icon) =>
    Container(
      margin: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF33235E), Color(0xFF151525), Color(0xFF5B285B)],
        ),
      ),
      child: Stack(children: [
        Center(child: Icon(icon, size: 100, color: Colors.white24)),
        Positioned(left: 20, right: 90, bottom: 28, child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('@$creator', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            Text(caption),
            const SizedBox(height: 8),
            Text(tr('Valid views ne kawai ake biya.', 'Only validated views are rewarded.'),
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ],
        )),
        Positioned(right: 18, bottom: 32, child: Column(children: const [
          Icon(Icons.favorite_border, size: 30), SizedBox(height: 5),
          Icon(Icons.mode_comment_outlined, size: 28), SizedBox(height: 18),
          Icon(Icons.share_outlined, size: 28),
        ])),
      ]),
    );
}

class UploadPage extends StatelessWidget {
  final String Function(String, String) tr;
  const UploadPage({super.key, required this.tr});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.cloud_upload_outlined, size: 76, color: Color(0xFFB8A5FF)),
        const SizedBox(height: 16),
        Text(tr('Ɗora bidiyo', 'Upload a video'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text(tr(
          'A production za a haɗa wannan da Firebase Storage, moderation da izinin masu bidiyon.',
          'In production this connects to Firebase Storage, moderation and uploader consent.',
        ), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(
            title: Text(tr('Upload bai haɗu ba tukuna', 'Upload is not connected yet')),
            content: Text(tr('Wannan demo ne. Za a haɗa ainihin upload bayan an saita backend.', 'This is a demo. Real uploads are enabled after backend setup.')),
          )),
          icon: const Icon(Icons.video_file),
          label: Text(tr('Zaɓi bidiyo', 'Choose video')),
        ),
      ]),
    ),
  );
}

class WalletPage extends StatelessWidget {
  final String Function(String, String) tr;
  final int balance;
  final int validViews;
  final VoidCallback onWithdraw;
  const WalletPage({super.key, required this.tr, required this.balance, required this.validViews, required this.onWithdraw});

  @override
  Widget build(BuildContext context) {
    final canWithdraw = balance >= minimumWithdrawal;
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text(tr('Wallet ɗina', 'My wallet'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [Color(0xFF7655E8), Color(0xFF34205F)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr('Jimillar kuɗi', 'Available balance'), style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text('₦$balance', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Text(tr('Valid views: $validViews', 'Valid views: $validViews')),
          Text(tr('₦50 ga kowane valid view', '₦50 per valid view')),
        ]),
      ),
      const SizedBox(height: 20),
      ListTile(
        leading: const Icon(Icons.lock_clock),
        title: Text(tr('Mafi ƙarancin cire kuɗi', 'Minimum withdrawal')),
        trailing: const Text('₦25,000', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      const SizedBox(height: 10),
      FilledButton.icon(
        onPressed: onWithdraw,
        icon: const Icon(Icons.account_balance),
        label: Text(tr('Nemi withdrawal', 'Request withdrawal')),
      ),
      if (!canWithdraw)
        Padding(padding: const EdgeInsets.only(top: 12),
          child: Text(tr('Za ka iya cire kuɗi idan balance ya kai ₦25,000.', 'Withdrawal unlocks when your balance reaches ₦25,000.'),
            textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60))),
      const SizedBox(height: 24),
      Text(tr('Muhimmi', 'Important'), style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(tr(
        'Wannan demo yana nuna lissafi ne kawai. Server dole ne ya tabbatar da valid views da balance kafin a biya.',
        'This demo only displays the calculation. The server must validate views and balances before any payout.',
      ), style: const TextStyle(color: Colors.white60)),
    ]);
  }
}

class SettingsPage extends StatelessWidget {
  final String language;
  final ValueChanged<String> onLanguageChanged;
  final String Function(String, String) tr;
  const SettingsPage({super.key, required this.language, required this.onLanguageChanged, required this.tr});

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Text(tr('Saiti', 'Settings'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 18),
    Text(tr('Zaɓi yare', 'Choose language')),
    const SizedBox(height: 8),
    DropdownButtonFormField<String>(
      value: language,
      items: const ['Hausa', 'English', 'French', 'Arabic', 'Yoruba', 'Igbo']
        .map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
      onChanged: (v) { if (v != null) onLanguageChanged(v); },
      decoration: const InputDecoration(border: OutlineInputBorder()),
    ),
    const SizedBox(height: 20),
    ListTile(leading: const Icon(Icons.person_outline), title: Text(tr('Account', 'Account')), subtitle: Text(tr('Register da Login za a haɗa da Firebase.', 'Registration and login will be connected to Firebase.'))),
    ListTile(leading: const Icon(Icons.verified_user_outlined), title: Text(tr('Tsaro da sirri', 'Safety and privacy')), subtitle: Text(tr('18+, consent, report da block za a buƙata.', '18+, consent, report and block are required.'))),
  ]);
}

class WithdrawalSheet extends StatelessWidget {
  final String Function(String, String) tr;
  const WithdrawalSheet({super.key, required this.tr});
  @override
  Widget build(BuildContext context) {
    String method = 'Bank transfer';
    return StatefulBuilder(builder: (context, setState) => Padding(
      padding: EdgeInsets.only(left: 20, right: 20, top: 24, bottom: MediaQuery.of(context).viewInsets.bottom + 24),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(tr('Withdrawal', 'Withdrawal'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: method,
          items: [
            DropdownMenuItem(value: 'Bank transfer', child: Text(tr('Bank transfer', 'Bank transfer'))),
            const DropdownMenuItem(value: 'OPay', child: Text('OPay')),
            const DropdownMenuItem(value: 'PalmPay', child: Text('PalmPay')),
          ],
          onChanged: (v) => setState(() => method = v ?? 'Bank transfer'),
          decoration: InputDecoration(labelText: tr('Hanyar karɓa', 'Payout method'), border: const OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        TextField(decoration: InputDecoration(labelText: tr('Account name', 'Account name'), border: const OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(keyboardType: TextInputType.number, decoration: InputDecoration(labelText: tr('Account number', 'Account number'), border: const OutlineInputBorder())),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: () => Navigator.pop(context),
          child: Text(tr('Ci gaba (demo)', 'Continue (demo)')),
        )),
        Text(tr('Demo ne: ba a aika kuɗi ko bayanan banki zuwa ko ina.', 'Demo only: no payout or bank details are transmitted.'),
          style: const TextStyle(color: Colors.white54, fontSize: 12)),
      ]),
    ));
  }
}
