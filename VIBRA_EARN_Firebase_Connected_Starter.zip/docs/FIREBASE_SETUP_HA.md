# Haɗa Firebase da VIBRA EARN

An saka fayil ɗin Android Firebase config a:
`android/app/google-services.json`

Project ID: `vibra-earn`
Android package: `com.vibra.earn`

## Muhimmi
Wannan starter ZIP ya ƙunshi Firebase config da Flutter dependencies. Ba a gama Firebase initialization ko Android Gradle plugin setup ba, kuma ba a haɗa authentication/database/storage na gaske ba tukuna.

## Matakan da developer zai kammala
1. Samar da Android platform files ta Flutter.
2. Saita Google Services Gradle plugin a Gradle files bisa Firebase docs.
3. Gudanar da `flutter pub get`.
4. Samar da `lib/firebase_options.dart` ta `flutterfire configure`.
5. Kira `Firebase.initializeApp` kafin `runApp`.
6. Kunna Authentication a Firebase Console.
7. Ƙirƙiri Firestore da Storage; saita Security Rules.
8. Gina Cloud Functions domin tabbatar da valid views da ledger; kada client ya ƙara wallet balance.
9. Gwada Android build kafin release.

Kada a saka service-account private keys ko payout provider secret keys a cikin app.
